-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 06 mai 2024 à 10:28
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `project_bdd`
--

-- --------------------------------------------------------

--
-- Structure de la table `activity_sector`
--

CREATE TABLE `activity_sector` (
  `id_activity_sector` int(11) NOT NULL,
  `name_activity_sector` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `activity_sector`
--

INSERT INTO `activity_sector` (`id_activity_sector`, `name_activity_sector`) VALUES
(1, 'Industrie chimique'),
(2, 'Agriculture'),
(3, 'Transport routier'),
(4, 'Industrie manufacturière'),
(5, 'Production d\'électricité'),
(6, 'Construction'),
(7, 'Services administratifs'),
(8, 'Commerce de détail'),
(9, 'Services de restauration'),
(10, 'Secteur médical'),
(11, 'Secteur éducatif'),
(12, 'Tourisme'),
(13, 'Télécommunications'),
(14, 'Technologies de l\'information'),
(15, 'Finance et assurances'),
(16, 'Immobilier'),
(17, 'Arts et divertissement');

-- --------------------------------------------------------

--
-- Structure de la table `administrative_agents`
--

CREATE TABLE `administrative_agents` (
  `id_employee` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `administrative_agents`
--

INSERT INTO `administrative_agents` (`id_employee`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(17);

-- --------------------------------------------------------

--
-- Structure de la table `agencies`
--

CREATE TABLE `agencies` (
  `id_agency` int(11) NOT NULL,
  `name_agency` varchar(50) DEFAULT NULL,
  `adress_agency` varchar(100) DEFAULT NULL,
  `name_city` char(50) NOT NULL,
  `name_region` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `agencies`
--

INSERT INTO `agencies` (`id_agency`, `name_agency`, `adress_agency`, `name_city`, `name_region`) VALUES
(1, 'Agence de Colmar', 'Avenue D\'Alsace, 123', 'colmar', 'Grand Est'),
(2, 'Agence de Strasbourg', '143 Avenue de Colmar', 'strasbourg', 'Grand Est'),
(3, 'Agence de Bayonne', 'Route d\'Arroussets, 64100', 'bayonne', 'Nouvelle-Aquitaine'),
(4, 'Agence de Bordeaux', '9 Rue Bernard Palissy, 63000', 'bordeaux', 'Nouvelle-Aquitaine'),
(5, 'Agence de Vichy', 'Allée des Ailes, 03200', 'Vichy', 'Auvergne-Rhône-Alpes'),
(6, 'Agence de Clermont Ferrand', '9 Rue Bernard Palissy, 63000', 'clermont ferrand', 'Auvergne-Rhône-Alpes'),
(7, 'Agence d\'Alençon', '115 Rue Nicolas Appert, 61000', 'alençon', 'Normandie'),
(8, 'Agence de Caen', '88 Boulevard Maréchal Leclerc, 14000', 'caen', 'Normandie'),
(9, 'Agence de Dijon', '36-38 Rue de la Liberté, 21000', 'dijon', 'Bourgogne-Franche-Comté'),
(10, 'Agence de Brest', '148 Route de Gouesnou, 29200', 'brest', 'Bretagne'),
(11, 'Agence de Rennes', 'Centre Commercial, 35000', 'rennes', 'Bretagne'),
(12, 'Agence d\'Orléans', 'Boulevard de Verdun, 45000', 'orléans', 'Centre-Val de Loire'),
(13, 'Agence de Tours', 'Zone Fuzaparc, 37100', 'Tours', 'Centre-Val de Loire'),
(14, 'Agence d\'Ajaccio', 'Boulevard Louis Campi, 20090', 'ajacio', 'Corse'),
(15, 'Agence de Bastia', 'Rue Font Neuve, 20200', 'bastia', 'Corse'),
(16, 'Agence de Besançon', 'Rue François Villon, 25000', 'besançon', 'Bourgogne-Franche-Comté'),
(17, 'Agence de Rouen', 'Rue du Gros Horloge, 76000', 'Rouen', 'Normandie'),
(18, 'Agence du Havre', 'Quai Colbert, 76600', 'le Havre', 'Normandie'),
(19, 'Agence de Saint-Denis', 'Boulevard Félix Faure, 93200', 'saint-denis', 'Île-de-France'),
(20, 'Agence de Paris', 'Boulevard de Clichy, 75018', 'Paris', 'Île-de-France'),
(21, 'Agence de Nîmes', 'Boulevard Gambetta, 30000', 'nimes', 'Occitanie'),
(22, 'Agence de Montpellier', 'Avenue de Toulouse, 34070', 'montpellier', 'Occitanie'),
(23, 'Agence de Limoges', 'Boulevard de Beaublanc, 87100', 'limoges', 'Nouvelle-Aquitaine'),
(24, 'Agence de Nancy', 'Rue Saint-Dizier, 54000', 'nancy', 'Grand Est'),
(25, 'Agence de Metz', 'Avenue Robert Schuman, 57000', 'metz', 'Grand Est'),
(26, 'Agence d\'Albi', 'Rue de Bourdès, 81000', 'albi', 'Occitanie'),
(27, 'Agence de Toulouse', 'Place du Capitole, 31000', 'toulouse', 'Occitanie'),
(28, 'Agence d\'Arras', 'Avenue Winston Churchill, 62000', 'arras', 'Hauts-de-France'),
(29, 'Agence de Lille', 'Place du Général de Gaulle, 59000', 'lille', 'Hauts-de-France'),
(30, 'Agence d\'Angers', 'Boulevard du Maréchal Foch, 49100', 'angers', 'Pays de la Loire'),
(31, 'Agence de Nantes', 'Avenue Flora Tristan, 44331', 'nantes', 'Pays de la Loire'),
(32, 'Agence d\'Amiens', 'Quai Charles Tellier, 80000', 'amiens', 'Hauts-de-France'),
(33, 'Agence de La Rochelle', 'Rue de la Scierie, 17000', 'la rochelle', 'Nouvelle-Aquitaine'),
(34, 'Agence de Poitiers', 'Rue de la Maison Coupée, 86000', 'poitier', 'Nouvelle-Aquitaine'),
(35, 'Agence de Marseille', 'Boulevard Schloesing, 13009', 'marseille', 'Provence-Alpes-Côte-d-Azur'),
(36, 'Agence de Nice', 'Avenue Jean Médecin, 06000', 'nice', 'Provence-Alpes-Côte-d-Azur'),
(37, 'Agence de Lyon', 'Place Gabriel Péri, 69007', 'lyon', 'Auvergne-Rhône-Alpes'),
(38, 'Agence de Grenoble', 'Rue Félix Poulat, 38000', 'grenoble', 'Auvergne-Rhône-Alpes');

-- --------------------------------------------------------

--
-- Structure de la table `agency_heads`
--

CREATE TABLE `agency_heads` (
  `id_employee` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `agency_heads`
--

INSERT INTO `agency_heads` (`id_employee`) VALUES
(38),
(39),
(40),
(41),
(42),
(43),
(44),
(45),
(46),
(47),
(48),
(49),
(50);

-- --------------------------------------------------------

--
-- Structure de la table `city`
--

CREATE TABLE `city` (
  `name_city` char(50) NOT NULL,
  `name_region` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `city`
--

INSERT INTO `city` (`name_city`, `name_region`) VALUES
('clermont ferrand', 'Auvergne-Rhône-Alpes'),
('grenoble', 'Auvergne-Rhône-Alpes'),
('lyon', 'Auvergne-Rhône-Alpes'),
('Vichy', 'Auvergne-Rhône-Alpes'),
('besançon', 'Bourgogne-Franche-comté'),
('dijon', 'Bourgogne-Franche-Comté'),
('brest', 'bretagne'),
('rennes', 'bretagne'),
('orléans', 'centre-val de loire'),
('Tours', 'centre-val de loire'),
('ajacio', 'corse'),
('bastia', 'corse'),
('colmar', 'Grand Est'),
('metz', 'Grand Est'),
('nancy', 'Grand Est'),
('strasbourg', 'Grand Est'),
('amiens', 'Hauts-de-France'),
('arras', 'Hauts-de-France'),
('lille', 'Hauts-de-France'),
('Paris', 'Île-de-france'),
('saint-denis', 'Île-de-france'),
('alençon', 'Normandie'),
('caen', 'Normandie'),
('le Havre', 'Normandie'),
('Rouen', 'Normandie'),
('bayonne', 'Nouvelle-Aquitaine'),
('bordeaux', 'Nouvelle-Aquitaine'),
('la rochelle', 'Nouvelle-Aquitaine'),
('limoges', 'Nouvelle-Aquitaine'),
('poitier', 'Nouvelle-Aquitaine'),
('albi', 'Occitanie'),
('montpellier', 'Occitanie'),
('nimes', 'Occitanie'),
('toulouse', 'Occitanie'),
('angers', 'Pays de la loire'),
('nantes', 'pays de la loire'),
('marseille', 'Provence-Alpes-Côte-d-Azur'),
('nice', 'Provence-Alpes-Côte-d-Azur'),
('toulon', 'Provence-Alpes-Côte-d-Azur');

-- --------------------------------------------------------

--
-- Structure de la table `create_`
--

CREATE TABLE `create_` (
  `id_employee` int(11) NOT NULL,
  `id_report` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `create_`
--

INSERT INTO `create_` (`id_employee`, `id_report`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10),
(11, 11),
(12, 12),
(13, 13),
(14, 14),
(15, 15),
(16, 16),
(17, 17),
(17, 18),
(17, 19),
(17, 20);

-- --------------------------------------------------------

--
-- Structure de la table `data_sensors`
--

CREATE TABLE `data_sensors` (
  `id_data_sensors` int(11) NOT NULL,
  `date_data` date DEFAULT NULL,
  `data` int(11) DEFAULT NULL,
  `id_sensor` int(11) NOT NULL,
  `name_gas` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `data_sensors`
--

INSERT INTO `data_sensors` (`id_data_sensors`, `date_data`, `data`, `id_sensor`, `name_gas`) VALUES
(1, '2020-01-15', 3, 1, 'CH4'),
(2, '2020-02-16', 3, 1, 'CH4'),
(3, '2023-03-17', 440, 1, 'CH4'),
(4, '2020-05-18', 1, 1, 'CH4'),
(5, '2023-06-19', 460, 21, 'CH4'),
(6, '2023-07-20', 2, 1, 'CH4'),
(7, '2020-08-21', 1, 1, 'CH4'),
(8, '2023-09-22', 453, 1, 'CH4'),
(9, '2020-10-23', 2, 1, 'CH4'),
(10, '2023-11-24', 2, 1, 'CH4'),
(11, '2023-12-15', 485, 2, 'CH4'),
(12, '2022-01-16', 2, 2, 'CH4'),
(13, '2022-02-17', 1, 2, 'CH4'),
(14, '2022-03-18', 492, 2, 'CH4'),
(15, '2022-04-19', 2, 2, 'CH4'),
(16, '2022-05-20', 1, 2, 'CH4'),
(17, '2022-06-21', 1, 2, 'CH4'),
(18, '2022-07-22', 0, 2, 'CH4'),
(19, '2022-08-23', 0, 2, 'CH4'),
(20, '2022-09-24', 0, 2, 'CH4'),
(21, '2022-10-15', 3, 3, 'N2O'),
(22, '2022-11-16', 3, 3, 'N2O'),
(23, '2022-12-17', 440, 3, 'N2O'),
(24, '2021-01-18', 1, 3, 'N2O'),
(25, '2021-02-19', 460, 3, 'N2O'),
(26, '2021-03-20', 2, 3, 'N2O'),
(27, '2021-04-21', 1, 3, 'N2O'),
(28, '2021-05-22', 453, 3, 'N2O'),
(29, '2021-06-23', 2, 3, 'N2O'),
(30, '2021-07-24', 2, 3, 'N2O'),
(31, '2021-08-15', 485, 4, 'N2O'),
(32, '2021-09-16', 2, 4, 'N2O'),
(33, '2021-10-17', 1, 4, 'N2O'),
(34, '2021-11-18', 492, 4, 'N2O'),
(35, '2021-12-19', 2, 4, 'N2O'),
(36, '2020-01-20', 1, 4, 'N2O'),
(37, '2020-02-21', 1, 4, 'N2O'),
(38, '2020-03-22', 0, 4, 'N2O'),
(39, '2020-04-23', 0, 4, 'N2O'),
(40, '2020-05-24', 0, 4, 'N2O'),
(41, '2020-06-15', 3, 5, 'PFC'),
(42, '2020-07-16', 3, 5, 'PFC'),
(43, '2020-08-17', 440, 5, 'PFC'),
(44, '2020-09-18', 1, 5, 'PFC'),
(45, '2020-10-19', 460, 5, 'PFC'),
(46, '2020-11-20', 2, 21, 'PFC'),
(47, '2020-12-21', 1, 5, 'PFC'),
(48, '2019-02-22', 453, 5, 'PFC'),
(49, '2019-03-23', 2, 5, 'PFC'),
(50, '2019-04-24', 2, 5, 'PFC'),
(51, '2019-05-15', 485, 6, 'PFC'),
(52, '2019-06-16', 2, 6, 'PFC'),
(53, '2019-07-17', 1, 6, 'PFC'),
(54, '2019-08-18', 492, 6, 'PFC'),
(55, '2019-09-19', 2, 6, 'PFC'),
(56, '2019-10-20', 1, 6, 'PFC'),
(57, '2019-11-21', 1, 6, 'PFC'),
(58, '2019-12-22', 0, 6, 'PFC'),
(59, '2019-01-23', 0, 6, 'PFC'),
(60, '2018-01-24', 0, 6, 'PFC'),
(61, '2018-02-15', 3, 7, 'HFC'),
(62, '2018-03-16', 3, 7, 'HFC'),
(63, '2020-04-17', 440, 7, 'HFC'),
(64, '2018-05-18', 1, 7, 'HFC'),
(65, '2018-06-19', 460, 7, 'HFC'),
(66, '2018-07-20', 2, 7, 'HFC'),
(67, '2018-08-21', 1, 7, 'HFC'),
(68, '2018-09-22', 453, 7, 'HFC'),
(69, '2020-10-23', 2, 7, 'HFC'),
(70, '2020-11-24', 2, 7, 'HFC'),
(71, '2018-12-15', 485, 8, 'HFC'),
(72, '2017-01-16', 2, 8, 'HFC'),
(73, '2017-01-17', 1, 8, 'HFC'),
(74, '2020-01-18', 492, 8, 'HFC'),
(75, '2017-01-19', 2, 21, 'HFC'),
(76, '2017-01-20', 1, 8, 'HFC'),
(77, '2017-01-21', 1, 8, 'HFC'),
(78, '2017-01-22', 0, 8, 'HFC'),
(79, '2017-01-23', 0, 8, 'HFC'),
(80, '2017-01-24', 0, 8, 'HFC'),
(81, '2017-02-15', 3, 9, 'SF6'),
(82, '2017-02-16', 3, 9, 'SF6'),
(83, '2017-02-17', 440, 9, 'SF6'),
(84, '2017-02-18', 1, 9, 'SF6'),
(85, '2017-02-19', 460, 9, 'SF6'),
(86, '2017-02-20', 2, 9, 'SF6'),
(87, '2017-02-21', 1, 9, 'SF6'),
(88, '2017-02-22', 453, 9, 'SF6'),
(89, '2017-02-23', 2, 9, 'SF6'),
(90, '2017-02-24', 2, 9, 'SF6'),
(91, '2017-03-15', 485, 10, 'SF6'),
(92, '2017-03-16', 2, 10, 'SF6'),
(93, '2017-03-17', 1, 10, 'SF6'),
(94, '2017-03-18', 492, 10, 'SF6'),
(95, '2017-03-19', 2, 10, 'SF6'),
(96, '2017-03-20', 1, 10, 'SF6'),
(97, '2017-03-21', 1, 10, 'SF6'),
(98, '2017-03-22', 0, 10, 'SF6'),
(99, '2017-03-23', 0, 10, 'SF6'),
(100, '2017-03-24', 0, 10, 'SF6'),
(101, '2017-04-15', 3, 11, 'SO2'),
(102, '2017-04-16', 3, 11, 'SO2'),
(103, '2017-04-17', 440, 11, 'SO2'),
(104, '2017-04-18', 1, 11, 'SO2'),
(105, '2017-04-19', 460, 11, 'SO2'),
(106, '2017-04-20', 2, 11, 'SO2'),
(107, '2017-04-21', 1, 11, 'SO2'),
(108, '2017-04-22', 453, 11, 'SO2'),
(109, '2017-04-23', 2, 11, 'SO2'),
(110, '2017-04-24', 2, 11, 'SO2'),
(111, '2017-05-15', 485, 12, 'SO2'),
(112, '2017-05-16', 2, 12, 'SO2'),
(113, '2017-05-17', 1, 12, 'SO2'),
(114, '2017-05-18', 492, 12, 'SO2'),
(115, '2017-05-19', 2, 12, 'SO2'),
(116, '2017-05-20', 1, 12, 'SO2'),
(117, '2017-05-21', 1, 12, 'SO2'),
(118, '2017-05-22', 0, 12, 'SO2'),
(119, '2017-05-23', 0, 12, 'SO2'),
(120, '2017-05-24', 0, 12, 'SO2'),
(121, '2017-06-15', 3, 13, 'NOx'),
(122, '2017-06-16', 3, 13, 'NOx'),
(123, '2017-06-17', 440, 13, 'NOx'),
(124, '2017-06-18', 1, 13, 'NOx'),
(125, '2017-06-19', 460, 13, 'NOx'),
(126, '2017-06-20', 2, 13, 'NOx'),
(127, '2017-06-21', 1, 13, 'NOx'),
(128, '2017-06-22', 453, 13, 'NOx'),
(129, '2017-06-23', 2, 13, 'NOx'),
(130, '2017-06-24', 2, 13, 'NOx'),
(131, '2017-07-15', 485, 14, 'NOx'),
(132, '2017-07-16', 2, 14, 'NOx'),
(133, '2017-07-17', 1, 14, 'NOx'),
(134, '2017-07-18', 492, 14, 'NOx'),
(135, '2017-07-19', 2, 14, 'NOx'),
(136, '2017-07-20', 1, 14, 'NOx'),
(137, '2017-07-21', 1, 14, 'NOx'),
(138, '2017-07-22', 0, 14, 'NOx'),
(139, '2017-07-23', 0, 14, 'NOx'),
(140, '2017-07-24', 0, 14, 'NOx'),
(141, '2017-08-15', 3, 15, 'NH3'),
(142, '2017-08-16', 3, 15, 'NH3'),
(143, '2017-08-17', 440, 15, 'NH3'),
(144, '2017-08-18', 1, 15, 'NH3'),
(145, '2017-08-19', 460, 15, 'NH3'),
(146, '2017-08-20', 2, 15, 'NH3'),
(147, '2017-08-21', 1, 15, 'NH3'),
(148, '2017-08-22', 453, 15, 'NH3'),
(149, '2017-08-23', 2, 15, 'NH3'),
(150, '2017-08-24', 2, 15, 'NH3'),
(151, '2017-09-15', 485, 16, 'NH3'),
(152, '2017-09-16', 2, 16, 'NH3'),
(153, '0000-00-00', 1, 16, 'NH3'),
(154, '2017-09-18', 492, 16, 'NH3'),
(155, '2017-09-19', 2, 16, 'NH3'),
(156, '2017-09-20', 1, 16, 'NH3'),
(157, '2017-09-21', 1, 16, 'NH3'),
(158, '2017-09-22', 0, 16, 'NH3'),
(159, '2017-09-23', 0, 16, 'NH3'),
(160, '2017-09-24', 0, 16, 'NH3'),
(161, '2016-01-15', 3, 17, 'CO'),
(162, '2016-01-16', 3, 17, 'CO'),
(163, '2016-01-17', 440, 17, 'CO'),
(164, '2016-01-18', 1, 17, 'CO'),
(165, '2016-01-19', 460, 17, 'CO'),
(166, '2016-01-20', 2, 17, 'CO'),
(167, '2016-01-21', 1, 17, 'CO'),
(168, '2016-01-22', 453, 17, 'CO'),
(169, '2016-01-23', 2, 17, 'CO'),
(170, '2016-01-24', 2, 17, 'CO'),
(171, '2016-02-15', 485, 18, 'CO'),
(172, '2016-02-16', 2, 18, 'CO'),
(173, '2016-02-17', 1, 18, 'CO'),
(174, '2016-02-18', 492, 18, 'CO'),
(175, '2016-02-19', 2, 18, 'CO'),
(176, '2016-02-20', 1, 18, 'CO'),
(177, '2016-02-21', 1, 18, 'CO'),
(178, '2016-02-22', 0, 18, 'CO'),
(179, '2016-02-23', 0, 18, 'CO'),
(180, '2016-02-24', 0, 18, 'CO'),
(181, '2016-03-15', 3, 19, 'COVNM'),
(182, '2016-03-16', 3, 19, 'COVNM'),
(183, '2016-03-17', 440, 19, 'COVNM'),
(184, '2016-03-18', 1, 19, 'COVNM'),
(185, '2016-03-19', 460, 19, 'COVNM'),
(186, '2016-03-20', 2, 19, 'COVNM'),
(187, '2016-03-21', 1, 19, 'COVNM'),
(188, '2016-03-22', 453, 19, 'COVNM'),
(189, '2016-03-23', 2, 19, 'COVNM'),
(190, '2016-03-24', 2, 19, 'COVNM'),
(191, '2016-04-15', 485, 20, 'COVNM'),
(192, '2016-04-16', 2, 20, 'COVNM'),
(193, '2016-04-17', 1, 20, 'COVNM'),
(194, '2016-04-18', 492, 20, 'COVNM'),
(195, '2016-04-19', 2, 20, 'COVNM'),
(196, '2016-04-20', 1, 20, 'COVNM'),
(197, '2016-04-21', 1, 20, 'COVNM'),
(198, '2016-04-22', 0, 20, 'COVNM'),
(199, '2016-04-23', 0, 20, 'COVNM'),
(200, '2016-04-24', 0, 20, 'COVNM');

-- --------------------------------------------------------

--
-- Structure de la table `gas`
--

CREATE TABLE `gas` (
  `name_gas` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `gas`
--

INSERT INTO `gas` (`name_gas`) VALUES
('CH4'),
('CO'),
('COVNM'),
('HFC'),
('N2O'),
('NH3'),
('NOx'),
('PFC'),
('SF6'),
('SO2');

-- --------------------------------------------------------

--
-- Structure de la table `ges`
--

CREATE TABLE `ges` (
  `name_gas` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `ges`
--

INSERT INTO `ges` (`name_gas`) VALUES
('CH4'),
('HFC'),
('N2O'),
('PFC'),
('SF6');

-- --------------------------------------------------------

--
-- Structure de la table `gra`
--

CREATE TABLE `gra` (
  `name_gas` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `gra`
--

INSERT INTO `gra` (`name_gas`) VALUES
('CO'),
('COVNM'),
('NH3'),
('NOx'),
('SO2');

-- --------------------------------------------------------

--
-- Structure de la table `mention`
--

CREATE TABLE `mention` (
  `id_report` int(11) NOT NULL,
  `name_gas` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `region`
--

CREATE TABLE `region` (
  `name_region` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `region`
--

INSERT INTO `region` (`name_region`) VALUES
('Auvergne-Rhône-Alpes'),
('Bourgogne-Franche-Comté'),
('Bretagne'),
('Centre-Val de Loire'),
('Corse'),
('Grand Est'),
('Hauts-de-France'),
('Île-de-France'),
('Normandie'),
('Nouvelle-Aquitaine'),
('Occitanie'),
('Pays de la Loire'),
('Provence-Alpes-Côte-d-Azur');

-- --------------------------------------------------------

--
-- Structure de la table `relate`
--

CREATE TABLE `relate` (
  `id_report` int(11) NOT NULL,
  `id_data_sensors` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `relate`
--

INSERT INTO `relate` (`id_report`, `id_data_sensors`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(1, 9),
(1, 10),
(2, 11),
(2, 12),
(2, 13),
(2, 14),
(2, 15),
(2, 16),
(2, 17),
(2, 18),
(2, 19),
(2, 20),
(3, 21),
(3, 22),
(3, 23),
(3, 24),
(3, 25),
(3, 26),
(3, 27),
(3, 28),
(3, 29),
(3, 30),
(4, 31),
(4, 32),
(4, 33),
(4, 34),
(4, 35),
(4, 36),
(4, 37),
(4, 38),
(4, 39),
(4, 40),
(5, 41),
(5, 42),
(5, 43),
(5, 44),
(5, 45),
(5, 46),
(5, 47),
(5, 48),
(5, 49),
(5, 50),
(6, 51),
(6, 52),
(6, 53),
(6, 54),
(6, 55),
(6, 56),
(6, 57),
(6, 58),
(6, 59),
(6, 60),
(7, 61),
(7, 62),
(7, 63),
(7, 64),
(7, 65),
(7, 66),
(7, 67),
(7, 68),
(7, 69),
(7, 70),
(8, 71),
(8, 72),
(8, 73),
(8, 74),
(8, 75),
(8, 76),
(8, 77),
(8, 78),
(8, 79),
(8, 80),
(9, 81),
(9, 82),
(9, 83),
(9, 84),
(9, 85),
(9, 86),
(9, 87),
(9, 88),
(9, 89),
(9, 90),
(10, 91),
(10, 92),
(10, 93),
(10, 94),
(10, 95),
(10, 96),
(10, 97),
(10, 98),
(10, 99),
(10, 100),
(11, 101),
(11, 102),
(11, 103),
(11, 104),
(11, 105),
(11, 106),
(11, 107),
(11, 108),
(11, 109),
(11, 110),
(12, 111),
(12, 112),
(12, 113),
(12, 114),
(12, 115),
(12, 116),
(12, 117),
(12, 118),
(12, 119),
(12, 120),
(13, 121),
(13, 122),
(13, 123),
(13, 124),
(13, 125),
(13, 126),
(13, 127),
(13, 128),
(13, 129),
(13, 130),
(14, 131),
(14, 132),
(14, 133),
(14, 134),
(14, 135),
(14, 136),
(14, 137),
(14, 138),
(14, 139),
(14, 140),
(15, 141),
(15, 142),
(15, 143),
(15, 144),
(15, 145),
(15, 146),
(15, 147),
(15, 148),
(15, 149),
(15, 150),
(16, 151),
(16, 152),
(16, 153),
(16, 154),
(16, 155),
(16, 156),
(16, 157),
(16, 158),
(16, 159),
(16, 160),
(16, 161),
(17, 162),
(17, 163),
(17, 164),
(17, 165),
(17, 166),
(17, 167),
(17, 168),
(17, 169),
(17, 170),
(18, 171),
(18, 172),
(18, 173),
(18, 174),
(18, 175),
(18, 176),
(18, 177),
(18, 178),
(18, 179),
(18, 180),
(19, 181),
(19, 182),
(19, 183),
(19, 184),
(19, 185),
(19, 186),
(19, 187),
(19, 188),
(19, 189),
(19, 190),
(20, 191),
(20, 192),
(20, 193),
(20, 194),
(20, 195),
(20, 196),
(20, 197),
(20, 198),
(20, 199),
(20, 200);

-- --------------------------------------------------------

--
-- Structure de la table `reports`
--

CREATE TABLE `reports` (
  `id_report` int(11) NOT NULL,
  `title` text DEFAULT NULL,
  `date_report` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `reports`
--

INSERT INTO `reports` (`id_report`, `title`, `date_report`) VALUES
(1, 'CH4 Emissions Report 2023', '2023-06-15'),
(2, 'Analysis of CH4 Emissions Trends 2024', '2024-04-01'),
(3, 'N2O Emissions Report 2023', '2023-06-30'),
(4, 'Analysis of N2O Emissions Trends 2018', '2018-05-01'),
(5, 'PFC Emissions Report 2023', '2023-07-15'),
(6, 'Analysis of PFC Emissions Trends 2024', '2024-06-01'),
(7, 'HFC Emissions Report 2023', '2023-07-30'),
(8, 'Analysis of HFC Emissions Trends 2019', '2019-07-15'),
(9, 'SF6 Emissions Report 2023', '2023-08-15'),
(10, 'Analysis of SF6 Emissions Trends 2020', '2020-08-30'),
(11, 'SO2 Emissions Report 2023', '2023-09-01'),
(12, 'Analysis of SO2 Emissions Trends 2019', '2019-09-15'),
(13, 'NOx Emissions Report 2023', '2023-09-30'),
(14, 'Analysis of NOx Emissions Trends 2024', '2024-10-01'),
(15, 'NH3 Emissions Report 2023', '2023-10-15'),
(16, 'Analysis of NH3 Emissions Trends 2024', '2024-10-30'),
(17, 'CO bio Emissions Report 2023', '2023-11-01'),
(18, 'Analysis of CO Emissions Trends 2018', '2018-11-15'),
(19, 'COVNM Volatile Organic Compounds Emissions Report 2023', '2023-11-30'),
(20, 'Analysis of COVNM Volatile Organic Compounds Emissions Trends 2024', '2024-12-01');

-- --------------------------------------------------------

--
-- Structure de la table `sensors`
--

CREATE TABLE `sensors` (
  `id_sensor` int(11) NOT NULL,
  `date_sensors` date DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `name_city` char(50) NOT NULL,
  `id_agency` int(11) NOT NULL,
  `id_employee` int(11) NOT NULL,
  `id_activity_sector` int(11) NOT NULL,
  `name_gas` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `sensors`
--

INSERT INTO `sensors` (`id_sensor`, `date_sensors`, `state`, `name_city`, `id_agency`, `id_employee`, `id_activity_sector`, `name_gas`) VALUES
(1, '2023-06-15', 'Operational', 'Paris', 1, 18, 1, 'CH4'),
(2, '2023-06-16', 'Operational', 'marseille', 2, 19, 1, 'CH4'),
(3, '2023-06-17', 'Operational', 'lyon', 3, 20, 2, 'N2O'),
(4, '2023-06-18', 'Under Maintenance', 'toulouse', 4, 21, 2, 'N2O'),
(5, '2023-06-19', 'Operational', 'bordeaux', 5, 22, 3, 'PFC'),
(6, '2023-06-20', 'Operational', 'nantes', 6, 23, 3, 'PFC'),
(7, '2023-06-21', 'Under Maintenance', 'strasbourg', 7, 24, 4, 'HFC'),
(8, '2023-06-22', 'Operational', 'lille', 8, 25, 4, 'HFC'),
(9, '2023-06-23', 'Operational', 'rennes', 9, 26, 5, 'SF6'),
(10, '2023-06-24', 'Operational', 'grenoble', 10, 27, 5, 'SF6'),
(11, '2023-06-25', 'Operational', 'nice', 11, 28, 6, 'SO2'),
(12, '2023-06-26', 'Operational', 'clermont ferrand', 12, 29, 6, 'SO2'),
(13, '2023-06-27', 'Under Maintenance', 'rouen', 13, 30, 7, 'NOx'),
(14, '2023-06-28', 'Operational', 'montpellier', 14, 31, 7, 'NOx'),
(15, '2023-06-29', 'Operational', 'dijon', 15, 32, 8, 'NH3'),
(16, '2023-06-30', 'Operational', 'ajacio', 16, 33, 8, 'NH3'),
(17, '2023-07-01', 'Operational', 'Metz', 17, 34, 9, 'CO'),
(18, '2023-07-02', 'Operational', 'bastia', 18, 35, 9, 'CO'),
(19, '2023-07-03', 'Under Maintenance', 'amiens', 19, 36, 10, 'COVNM'),
(20, '2023-07-04', 'Operational', 'besançon', 20, 37, 10, 'COVNM'),
(21, '2023-06-16', 'Operational', 'toulon', 2, 19, 1, 'CO');

-- --------------------------------------------------------

--
-- Structure de la table `staff`
--

CREATE TABLE `staff` (
  `id_employee` int(11) NOT NULL,
  `first_name_empl` varchar(100) DEFAULT NULL,
  `name_empl` varchar(100) DEFAULT NULL,
  `date_birth_empl` date DEFAULT NULL,
  `postal_adress` varchar(100) DEFAULT NULL,
  `start_date_empl` date DEFAULT NULL,
  `id_agency` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `staff`
--

INSERT INTO `staff` (`id_employee`, `first_name_empl`, `name_empl`, `date_birth_empl`, `postal_adress`, `start_date_empl`, `id_agency`) VALUES
(1, 'John', 'Doe', '1980-05-15', '123 Rue de la Poste, 75001 Paris', '2022-01-15', 20),
(2, 'Jane', 'Smith', '1985-08-20', '456 Avenue des Fleurs, 33000 Bordeaux', '2022-02-01', 4),
(3, 'Michael', 'Johnson', '1990-03-10', '789 Boulevard du Soleil, 13000 Marseille', '2022-02-15', 35),
(4, 'Emily', 'Brown', '1982-11-25', '321 Rue de la Lune, 59000 Lille', '2022-03-01', 29),
(5, 'David', 'Martinez', '1987-09-08', '987 Avenue de l\'Étoile, 34000 Montpellier', '2022-03-15', 22),
(6, 'Sophie', 'Garcia', '1993-06-18', '654 Chemin des Bois, 69000 Lyon', '2022-04-01', 37),
(7, 'William', 'Lopez', '1984-04-30', '147 Boulevard des Champs, 75008 Paris', '2022-04-15', 20),
(8, 'Olivia', 'Perez', '1989-01-12', '753 Rue des Roses, 44000 Nantes', '2022-05-01', 31),
(9, 'James', 'Rodriguez', '1981-07-05', '852 Avenue des Vents, 31000 Toulouse', '2022-05-15', 27),
(10, 'Emma', 'Hernandez', '1995-02-22', '369 Rue des Nuages, 59000 Lille', '2022-06-01', 29),
(11, 'Alexander', 'Gonzalez', '1983-10-17', '258 Avenue des Arbres, 13000 Marseille', '2022-06-15', 35),
(12, 'Mia', 'Lefebvre', '1992-08-11', '741 Chemin des Étoiles, 33000 Bordeaux', '2022-07-01', 4),
(13, 'Daniel', 'Leroy', '1986-05-28', '963 Rue de la Terre, 69000 Lyon', '2022-07-15', 37),
(14, 'Charlotte', 'Moreau', '1991-03-14', '159 Avenue des Oiseaux, 75015 Paris', '2022-08-01', 20),
(15, 'Ethan', 'Dubois', '1988-11-07', '456 Rue des Champs, 13000 Marseille', '2022-08-15', 35),
(16, 'Amelia', 'Roussel', '1980-09-24', '753 Boulevard des Fleurs, 33000 Bordeaux', '2022-09-01', 4),
(17, 'Noah', 'Fontaine', '1994-06-10', '852 Avenue du Soleil, 69000 Lyon', '2022-09-15', 37),
(18, 'Sophia', 'Chevalier', '1983-02-18', '369 Rue du Printemps, 75001 Paris', '2022-10-01', 20),
(19, 'Gabriel', 'Bertrand', '1986-12-05', '852 Avenue des Roses, 33000 Bordeaux', '2022-10-15', 4),
(20, 'Ava', 'Lemoine', '1990-07-20', '147 Boulevard de la Lune, 59000 Lille', '2022-11-01', 29),
(21, 'Leo', 'Caron', '1989-05-03', '654 Avenue des Champs, 13000 Marseille', '2022-11-15', 35),
(22, 'Chloe', 'Renard', '1993-09-08', '963 Rue de la Terre, 69000 Lyon', '2022-12-01', 37),
(23, 'Liam', 'Girard', '1982-03-18', '369 Boulevard du Printemps, 75001 Paris', '2022-12-15', 20),
(24, 'Zoe', 'Lecomte', '1995-01-30', '852 Avenue des Roses, 33000 Bordeaux', '2023-01-01', 4),
(25, 'Nathan', 'Meyer', '1984-08-11', '147 Boulevard de la Lune, 59000 Lille', '2023-01-15', 29),
(26, 'Lily', 'Blanc', '1991-07-22', '654 Avenue des Champs, 13000 Marseille', '2023-02-01', 35),
(27, 'Jacob', 'Marchand', '1987-11-05', '963 Rue de la Terre, 69000 Lyon', '2023-02-15', 37),
(28, 'Mia', 'Guerin', '1980-04-20', '369 Boulevard du Printemps, 75001 Paris', '2023-03-01', 20),
(29, 'Ethan', 'Blanchard', '1994-02-10', '852 Avenue des Roses, 33000 Bordeaux', '2023-03-15', 4),
(30, 'Emma', 'Brun', '1981-06-28', '147 Boulevard de la Lune, 59000 Lille', '2023-04-01', 29),
(31, 'Noah', 'Rey', '1985-09-15', '654 Avenue des Champs, 13000 Marseille', '2023-04-15', 35),
(32, 'Chloe', 'Barbier', '1992-11-25', '963 Rue de la Terre, 69000 Lyon', '2023-05-01', 37),
(33, 'Liam', 'Perrin', '1983-08-02', '369 Boulevard du Printemps, 75001 Paris', '2023-05-15', 20),
(34, 'Zoe', 'Bouchard', '1990-04-18', '852 Avenue des Roses, 33000 Bordeaux', '2023-06-01', 4),
(35, 'Nathan', 'Lemoine', '1986-10-03', '147 Boulevard de la Lune, 59000 Lille', '2023-06-15', 29),
(36, 'Lily', 'Dupont', '1982-12-20', '654 Avenue des Champs, 13000 Marseille', '2023-07-01', 35),
(37, 'Jacob', 'Moreau', '1995-05-10', '963 Rue de la Terre, 69000 Lyon', '2023-07-15', 37),
(38, 'Mia', 'Fournier', '1987-03-28', '369 Boulevard du Printemps, 75001 Paris', '2023-08-01', 20),
(39, 'Ethan', 'Garnier', '1991-01-15', '852 Avenue des Roses, 33000 Bordeaux', '2023-08-15', 4),
(40, 'Emma', 'Guillaume', '1980-07-02', '147 Boulevard de la Lune, 59000 Lille', '2023-09-01', 29),
(41, 'Noah', 'Durand', '1994-06-18', '654 Avenue des Champs, 13000 Marseille', '2023-09-15', 35),
(42, 'Chloe', 'Michel', '1989-03-10', '963 Rue de la Terre, 69000 Lyon', '2023-10-01', 37),
(43, 'Liam', 'Martin', '1981-09-28', '369 Boulevard du Printemps, 75001 Paris', '2023-10-15', 20),
(44, 'Zoe', 'Girard', '1995-12-15', '852 Avenue des Roses, 33000 Bordeaux', '2023-11-01', 4),
(45, 'Nathan', 'Lefevre', '1984-02-02', '147 Boulevard de la Lune, 59000 Lille', '2023-11-15', 29),
(46, 'Lily', 'Roux', '1991-04-18', '654 Avenue des Champs, 13000 Marseille', '2023-12-01', 35),
(47, 'Jacob', 'Caron', '1980-10-05', '963 Rue de la Terre, 69000 Lyon', '2023-12-15', 37),
(48, 'Mia', 'Simon', '1994-08-22', '369 Boulevard du Printemps, 75001 Paris', '2024-01-01', 20),
(49, 'Ethan', 'Petit', '1982-06-10', '852 Avenue des Roses, 33000 Bordeaux', '2024-01-15', 4),
(50, 'Emma', 'Morel', '1987-11-28', '147 Boulevard de la Lune, 59000 Lille', '2024-02-01', 29);

-- --------------------------------------------------------

--
-- Structure de la table `technical_agents`
--

CREATE TABLE `technical_agents` (
  `id_employee` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `technical_agents`
--

INSERT INTO `technical_agents` (`id_employee`) VALUES
(18),
(19),
(20),
(21),
(22),
(23),
(24),
(25),
(26),
(27),
(28),
(29),
(30),
(31),
(32),
(33),
(34),
(35),
(36),
(37);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `activity_sector`
--
ALTER TABLE `activity_sector`
  ADD PRIMARY KEY (`id_activity_sector`);

--
-- Index pour la table `administrative_agents`
--
ALTER TABLE `administrative_agents`
  ADD PRIMARY KEY (`id_employee`);

--
-- Index pour la table `agencies`
--
ALTER TABLE `agencies`
  ADD PRIMARY KEY (`id_agency`),
  ADD KEY `name_city` (`name_city`),
  ADD KEY `name_region` (`name_region`);

--
-- Index pour la table `agency_heads`
--
ALTER TABLE `agency_heads`
  ADD PRIMARY KEY (`id_employee`);

--
-- Index pour la table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`name_city`),
  ADD KEY `name_region` (`name_region`);

--
-- Index pour la table `create_`
--
ALTER TABLE `create_`
  ADD PRIMARY KEY (`id_employee`,`id_report`),
  ADD KEY `id_report` (`id_report`);

--
-- Index pour la table `data_sensors`
--
ALTER TABLE `data_sensors`
  ADD PRIMARY KEY (`id_data_sensors`),
  ADD KEY `id_sensor` (`id_sensor`),
  ADD KEY `name_gas` (`name_gas`);

--
-- Index pour la table `gas`
--
ALTER TABLE `gas`
  ADD PRIMARY KEY (`name_gas`);

--
-- Index pour la table `ges`
--
ALTER TABLE `ges`
  ADD PRIMARY KEY (`name_gas`);

--
-- Index pour la table `gra`
--
ALTER TABLE `gra`
  ADD PRIMARY KEY (`name_gas`);

--
-- Index pour la table `mention`
--
ALTER TABLE `mention`
  ADD PRIMARY KEY (`id_report`,`name_gas`),
  ADD KEY `name_gas` (`name_gas`);

--
-- Index pour la table `region`
--
ALTER TABLE `region`
  ADD PRIMARY KEY (`name_region`);

--
-- Index pour la table `relate`
--
ALTER TABLE `relate`
  ADD PRIMARY KEY (`id_report`,`id_data_sensors`),
  ADD KEY `id_data_sensors` (`id_data_sensors`);

--
-- Index pour la table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id_report`);

--
-- Index pour la table `sensors`
--
ALTER TABLE `sensors`
  ADD PRIMARY KEY (`id_sensor`),
  ADD KEY `name_city` (`name_city`),
  ADD KEY `id_agency` (`id_agency`),
  ADD KEY `id_employee` (`id_employee`),
  ADD KEY `id_activity_sector` (`id_activity_sector`),
  ADD KEY `name_gas` (`name_gas`);

--
-- Index pour la table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id_employee`),
  ADD KEY `id_agency` (`id_agency`);

--
-- Index pour la table `technical_agents`
--
ALTER TABLE `technical_agents`
  ADD PRIMARY KEY (`id_employee`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `administrative_agents`
--
ALTER TABLE `administrative_agents`
  ADD CONSTRAINT `administrative_agents_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `staff` (`id_employee`);

--
-- Contraintes pour la table `agencies`
--
ALTER TABLE `agencies`
  ADD CONSTRAINT `agencies_ibfk_1` FOREIGN KEY (`name_city`) REFERENCES `city` (`name_city`),
  ADD CONSTRAINT `agencies_ibfk_2` FOREIGN KEY (`name_region`) REFERENCES `region` (`name_region`);

--
-- Contraintes pour la table `agency_heads`
--
ALTER TABLE `agency_heads`
  ADD CONSTRAINT `agency_heads_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `staff` (`id_employee`);

--
-- Contraintes pour la table `city`
--
ALTER TABLE `city`
  ADD CONSTRAINT `city_ibfk_1` FOREIGN KEY (`name_region`) REFERENCES `region` (`name_region`);

--
-- Contraintes pour la table `create_`
--
ALTER TABLE `create_`
  ADD CONSTRAINT `create__ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `administrative_agents` (`id_employee`),
  ADD CONSTRAINT `create__ibfk_2` FOREIGN KEY (`id_report`) REFERENCES `reports` (`id_report`);

--
-- Contraintes pour la table `data_sensors`
--
ALTER TABLE `data_sensors`
  ADD CONSTRAINT `data_sensors_ibfk_1` FOREIGN KEY (`id_sensor`) REFERENCES `sensors` (`id_sensor`),
  ADD CONSTRAINT `data_sensors_ibfk_2` FOREIGN KEY (`name_gas`) REFERENCES `gas` (`name_gas`);

--
-- Contraintes pour la table `ges`
--
ALTER TABLE `ges`
  ADD CONSTRAINT `ges_ibfk_1` FOREIGN KEY (`name_gas`) REFERENCES `gas` (`name_gas`);

--
-- Contraintes pour la table `gra`
--
ALTER TABLE `gra`
  ADD CONSTRAINT `gra_ibfk_1` FOREIGN KEY (`name_gas`) REFERENCES `gas` (`name_gas`);

--
-- Contraintes pour la table `mention`
--
ALTER TABLE `mention`
  ADD CONSTRAINT `mention_ibfk_1` FOREIGN KEY (`id_report`) REFERENCES `reports` (`id_report`),
  ADD CONSTRAINT `mention_ibfk_2` FOREIGN KEY (`name_gas`) REFERENCES `gas` (`name_gas`);

--
-- Contraintes pour la table `relate`
--
ALTER TABLE `relate`
  ADD CONSTRAINT `relate_ibfk_1` FOREIGN KEY (`id_report`) REFERENCES `reports` (`id_report`),
  ADD CONSTRAINT `relate_ibfk_2` FOREIGN KEY (`id_data_sensors`) REFERENCES `data_sensors` (`id_data_sensors`);

--
-- Contraintes pour la table `sensors`
--
ALTER TABLE `sensors`
  ADD CONSTRAINT `sensors_ibfk_1` FOREIGN KEY (`name_city`) REFERENCES `city` (`name_city`),
  ADD CONSTRAINT `sensors_ibfk_2` FOREIGN KEY (`id_agency`) REFERENCES `agencies` (`id_agency`),
  ADD CONSTRAINT `sensors_ibfk_3` FOREIGN KEY (`id_employee`) REFERENCES `technical_agents` (`id_employee`),
  ADD CONSTRAINT `sensors_ibfk_4` FOREIGN KEY (`id_activity_sector`) REFERENCES `activity_sector` (`id_activity_sector`),
  ADD CONSTRAINT `sensors_ibfk_5` FOREIGN KEY (`name_gas`) REFERENCES `gas` (`name_gas`);

--
-- Contraintes pour la table `staff`
--
ALTER TABLE `staff`
  ADD CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`id_agency`) REFERENCES `agencies` (`id_agency`);

--
-- Contraintes pour la table `technical_agents`
--
ALTER TABLE `technical_agents`
  ADD CONSTRAINT `technical_agents_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `staff` (`id_employee`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
