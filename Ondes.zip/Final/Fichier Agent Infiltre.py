import matplotlib.pyplot as plt
import numpy as np
import sounddevice as sd
import os
import soundfile as sf
import wave

from datetime import datetime

# Fonction pour créer le répertoire principal s'il n'existe pas
def creer_dossier_principal():
    nom_dossier_principal = "Fichiers_resultats_envois"
    if not os.path.exists(nom_dossier_principal):
        os.mkdir(nom_dossier_principal)
    return nom_dossier_principal

# Fonction pour générer un nouveau dossier "Resultat_envoie_X"
def creer_nouveau_dossier(dossier_principal):
    base_nom = "Resultat_envoi"
    numero = 1

    while os.path.exists(os.path.join(dossier_principal, f"{base_nom}_{numero}")):
        numero += 1

    dossier = os.path.join(dossier_principal, f"{base_nom}_{numero}")
    os.mkdir(dossier)
    return dossier

# Création du répertoire principal et du dossier de résultats
dossier_principal = creer_dossier_principal()
chemin_dossier = creer_nouveau_dossier(dossier_principal)

# Programme principal
print("") 
print("Avez-vous un fichier texte contenant le message que vous souhaitez transmettre?")
reponse = str(input("")) 
if reponse.lower() in ["oui", "o", "y"]:
    print("Quel est le nom de votre fichier texte? (nom.txt) :")
    fichier = str(input("")) 
    fichier = open(fichier, "r")
    message = fichier.read()
else:
    print("Quel est votre message AGENT? :")
    message = str(input("")) 
    chemin_fichier = os.path.join(chemin_dossier, "texte.txt")
    with open(chemin_fichier, "w") as fichier:
        fichier.write(message)

# Conversion du message en ASCII binaire
a_bytes = bytes(message, "ascii") 
message_bin = " ".join(["{0:b}".format(x) for x in a_bytes])
print("")
print("Convertision du message :", message)
print("")
print("En binaire ASCII :", message_bin)
print("")

# Passage à une liste de int et suppression des espaces
message = message_bin
mes = "".join([bit for bit in message if bit != " "])
mes = [int(bit) for bit in mes]

# Calcul du CRC
poly = "101001"
mes.extend([0] * (len(poly) - 1))
for i in range(len(mes) - len(poly) + 1):
    if mes[i] == 0:
        continue
    for j in range(len(poly)):
        mes[i + j] ^= int(poly[j])
crc = ''.join(str(bit) for bit in mes[-(len(poly) - 1):])
print("le crc =", str(crc))
message_final = message + " " + crc
print("le message + crc  = ", str(message_final))

# Conversion en Manchester
message_a_transmettre = []
for bit in message_final:
    if bit == '1':
        message_a_transmettre += [1, 0]
    elif bit == '0':
        message_a_transmettre += [0, 1]
    else:
        message_a_transmettre += [-1, -1]
print("En Manchester :", message_a_transmettre)
print("")

# Modulation FSK
Fe = 44100
baud = 300
Nbits = len(message_a_transmettre)
Ns = int(Fe / baud)
N = int(Nbits * Ns)
M_duplique = np.repeat(message_a_transmettre, Ns)
t1 = np.linspace(0.0, Ns / Fe, Ns)
t = np.linspace(0.0, N / Fe, N)
A1, A2, A3 = 10, 20, 30
fp1, fp2, fp3 = 18400, 18600, 18500
P1 = [A1 * np.sin(2 * np.pi * fp1 * tt) for tt in t1]
P2 = [A2 * np.sin(2 * np.pi * fp2 * tt) for tt in t1]
P3 = [A3 * np.sin(2 * np.pi * fp3 * tt) for tt in t1]
FSK = []
for bit in message_a_transmettre:
    if bit == 1:
        FSK.extend(P1)
    elif bit == 0:
        FSK.extend(P2)
    else:
        FSK.extend(P3)

# Affichage
plt.figure(figsize=(10, 6))
plt.plot(t, M_duplique)
plt.xlabel('Temps [s]')
plt.title('Message binaire')
plt.savefig(os.path.join(chemin_dossier, "Message_binaire.png"))

plt.figure(figsize=(10, 6))
plt.plot(t, FSK)
plt.xlabel('Temps [s]')
plt.title('Modulation')
plt.savefig(os.path.join(chemin_dossier, "Modulation.png"))
plt.show()

# Enregistrement des résultats dans le dossier
dossier_resultats = os.path.join(chemin_dossier, "resultat.txt")
with open(dossier_resultats, "w") as fichier:
    fichier.write(str(FSK))
print("Résultats enregistrés dans le dossier :", chemin_dossier)

# Enregistrement et lecture du son
print("")
input("Appuyez sur Entrée pour écouter votre son")
sd.play(FSK, Fe)
sd.wait()
print("Son émis avec succès")

# Enregistrement audio
audio_path = os.path.join(chemin_dossier, "audio.wav")
sf.write(audio_path, FSK, 44100, subtype='PCM_16')
print("Son enregistré avec succès :", audio_path)
print("")
print("Programme terminé.")
