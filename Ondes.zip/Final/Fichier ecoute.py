# -*- coding: utf-8 -*-
"""
Created on Tue Dec 12 16:02:30 2023

@author: gluca
"""

""" Importation des modules qu'on utilisera """
import matplotlib.pyplot as plt
import numpy as np
import wave

""" Fonction qui nous permettra de lire un fichier wav """
def lire_fichier_wav(nom_fichier):
    with wave.open(nom_fichier, 'rb') as fichier_wav:
        # Récupérer les paramètres du fichier WAV
        framerate = fichier_wav.getframerate()
        nframes = fichier_wav.getnframes()
        # Lire les échantillons audio
        signal = np.frombuffer(fichier_wav.readframes(nframes), dtype=np.int16)
    return signal, framerate

""" Programme de démarrage """
print("Avez-vous un fichier en .txt ou en .wav? (txt/wav) :")
fichier_type = input("").strip()

if fichier_type == "txt":
    print("Quel est le nom de votre fichier? :")
    nom_fichier = input("").strip()
    with open(nom_fichier, "r") as fichier:
        message = fichier.read()[1:-1]  # Exclure les crochets [ ]
    # Transformer le contenu en liste de floats
    FSK = [float(x) for x in message.split(',') if x.strip()]
else:
    print("Quel est le nom de votre fichier? :")
    nom_fichier = input("").strip()
    # Lire le fichier WAV
    signal_audio, taux_echantillonnage = lire_fichier_wav(nom_fichier)
    FSK = list(signal_audio)

""" Partie DEMODULATION FSK ET ASK """   
Nbits = len(FSK) // 147
Fe = 44100  # Fréquence d'échantillonnage
baud = 300  # Débit souhaité
Ns = Fe // baud  # Nombre de symboles par bit
N = Nbits * Ns

message_demodule_FSK, son = [], []
y1, y2, y3 = [], [], []  # Résultats de l'intégration

# Génération des porteuses
A1, A2, A3 = 10, 20, 30
fp1, fp2, fp3 = 18400, 18600, 18500
t1 = np.linspace(0.0, Ns / Fe, Ns)
P1 = A1 * np.sin(2 * np.pi * fp1 * t1)
P2 = A2 * np.sin(2 * np.pi * fp2 * t1)
P3 = A3 * np.sin(2 * np.pi * fp3 * t1)

Porteuse1, Porteuse2, Porteuse3 = np.tile(P1, Nbits), np.tile(P2, Nbits), np.tile(P3, Nbits)
bit1, bit0, bit_1 = FSK * Porteuse1, FSK * Porteuse2, FSK * Porteuse3

# Méthode des trapèzes
for i in range(0, N, Ns):
    y1.append(np.trapz(bit1[i:i+Ns]))
    y2.append(np.trapz(bit0[i:i+Ns]))
    y3.append(np.trapz(bit_1[i:i+Ns]))

# Démodulation
for i in range(len(y1)):
    if abs(y1[i]) > abs(y2[i]) and abs(y1[i]) < abs(y3[i]):
        message_demodule_FSK.append(1)
        son.append(y1[i])
    elif abs(y2[i]) > abs(y1[i]) and abs(y2[i]) > abs(y3[i]):
        message_demodule_FSK.append(0)
        son.append(y2[i])
    elif abs(y3[i]) > abs(y1[i]) and abs(y3[i]) > abs(y2[i]):
        message_demodule_FSK.append(-1)
        son.append(y3[i])

""" Programme qui passe du message en Manchester à l'ASCII binaire """
message_final = ""
for i in range(0, len(message_demodule_FSK), 2):
    if message_demodule_FSK[i] == 1:
        message_final += '1'
    elif message_demodule_FSK[i] == 0:
        message_final += '0'
    else:
        message_final += ' '

# Conversion en liste d'entiers
mes = [int(bit) for bit in message_final if bit.isdigit()]

""" Vérification CRC """
poly = "101001"
mes.extend([0] * (len(poly) - 1))  # Ajouter des zéros
for i in range(len(mes) - len(poly) + 1):
    if mes[i] == 1:
        for j in range(len(poly)):
            mes[i + j] ^= int(poly[j])
crc = ''.join(map(str, mes[-(len(poly) - 1):]))
result_crc = crc == '0' * (len(poly) - 1)

if result_crc:
    print("Le CRC = 0, le message est bien reçu")
else:
    print("Le CRC != 0, le message n'est pas bien reçu")
    
print("Voici le message final en ASCII binaire :", message_final[:-len(poly) + 1])

""" Fonction pour passer d'un message binaire ASCII en texte """
def ASCII_Binaire_Vers_Texte(message):
    binaire = message.split()
    decimal = [int(b, 2) for b in binaire]
    return ''.join(chr(d) for d in decimal)

texte_final = ASCII_Binaire_Vers_Texte(message_final[:-len(poly) + 1])
print("\nVoici le message final :\n")
print(texte_final)
